package Exercicio2Sistema_de_Compra_online.Entities;

public class Cliente {

    public String nome;
    public String cpf;
    public String endereco;

    public Cliente(String nome, String cpf, String endereco) {

        this.nome = nome;
        this.cpf = cpf;
        this.endereco = endereco;
    }
}