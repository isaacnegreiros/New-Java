package Sistemas_do_Dia_a_Dia2_Refatorar.Entities;

public class Veículo {
    private String placa;
    private String tipo;
    private int horaEntrada;

    public Veículo(String placa, String tipo, int horaEntrada) {
        this.placa = placa;
        this.tipo = tipo;
        this.horaEntrada = horaEntrada;
    }

    public String getPlaca() {
        return placa;
    }

    public String getTipo() {
        return tipo;
    }

    public int getHoraEntrada() {
        return horaEntrada;
    }

    public int calcularTempo(int horaSaida) {
        return horaSaida - horaEntrada;
    }

    public double calcularPagamento(int horaSaida) {

        int tempo = calcularTempo(horaSaida);

        if (tempo <= 1) {
            return 10.0;
        } else {
            return 10.0 + (tempo - 1) * 5.0;
        }
    }
}
